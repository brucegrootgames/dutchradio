import { Play } from "lucide-react";
import { RadioStation } from "@shared/schema";
import { useAudio } from "@/lib/audio-context";

interface StationGridProps {
  stations: RadioStation[];
  isLoading?: boolean;
}

export function StationGrid({ stations, isLoading }: StationGridProps) {
  const { playStation } = useAudio();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-24">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden animate-pulse">
            <div className="aspect-video bg-gray-200"></div>
            <div className="p-4">
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-3 bg-gray-200 rounded mb-2"></div>
              <div className="flex justify-between">
                <div className="h-3 bg-gray-200 rounded w-20"></div>
                <div className="h-3 bg-gray-200 rounded w-12"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (stations.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Geen radiozenders gevonden.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-24">
      {stations.map((station) => (
        <div
          key={station.id}
          className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-all duration-200 group"
        >
          <div className={`aspect-video bg-gradient-to-br ${station.logoColor} flex items-center justify-center relative`}>
            <div className="text-white font-bold text-2xl">{station.logoText}</div>
            <button
              onClick={() => playStation(station)}
              className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 flex items-center justify-center transition-all duration-200"
            >
              <div className="w-16 h-16 bg-white bg-opacity-90 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Play className="text-gray-600 ml-1" size={24} fill="currentColor" />
              </div>
            </button>
          </div>
          <div className="p-4">
            <h3 className="font-semibold text-gray-900 mb-1">{station.name}</h3>
            <p className="text-sm text-light-text mb-2">{station.description}</p>
            <div className="flex items-center justify-between">
              <div className="text-xs text-light-text">
                {station.listeners.toLocaleString()} luisteraars
              </div>
              <div className="flex items-center space-x-1 text-xs text-light-text">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span>Live</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
