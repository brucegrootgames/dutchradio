import { useState } from "react";
import { Play, Pause, VolumeX, Volume2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useAudio } from "@/lib/audio-context";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export function AudioPlayer() {
  const {
    currentStation,
    isPlaying,
    isLoading,
    volume,
    error,
    togglePlayPause,
    stop,
    setVolume,
    clearError,
    playStation
  } = useAudio();

  const [showVolumeControl, setShowVolumeControl] = useState(false);

  if (!currentStation) return null;

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0] / 100);
  };

  const retryConnection = () => {
    clearError();
    if (currentStation) {
      playStation(currentStation);
    }
  };

  return (
    <>
      {/* Loading Overlay */}
      {isLoading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-sm mx-4">
            <div className="flex items-center space-x-3">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-dutch-blue"></div>
              <span className="text-gray-900">
                Verbinden met {currentStation.name}...
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Error Dialog */}
      <AlertDialog open={!!error} onOpenChange={() => clearError()}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center space-x-2">
              <span className="text-red-500">⚠️</span>
              <span>Verbindingsprobleem</span>
            </AlertDialogTitle>
            <AlertDialogDescription>
              {error}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={clearError}>Sluiten</AlertDialogCancel>
            <AlertDialogAction onClick={retryConnection}>
              Opnieuw proberen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Audio Player */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-40">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            {/* Current Station Info */}
            <div className="flex items-center space-x-4 flex-1 min-w-0">
              <div className="w-12 h-12 bg-dutch-blue rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-sm">
                  {currentStation.logoText}
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="font-semibold text-gray-900 truncate">
                  {currentStation.name}
                </h4>
                <p className="text-sm text-light-text truncate">
                  {currentStation.description}
                </p>
              </div>
            </div>

            {/* Audio Controls */}
            <div className="flex items-center space-x-4">
              <Button
                onClick={togglePlayPause}
                disabled={isLoading}
                className="w-10 h-10 bg-dutch-blue rounded-full hover:bg-blue-700 transition-colors p-0"
              >
                {isPlaying ? (
                  <Pause className="text-white" size={16} />
                ) : (
                  <Play className="text-white ml-0.5" size={16} fill="currentColor" />
                )}
              </Button>

              {/* Volume Control (Hidden on mobile) */}
              <div className="hidden md:flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowVolumeControl(!showVolumeControl)}
                  className="p-1"
                >
                  {volume === 0 ? (
                    <VolumeX className="text-light-text" size={16} />
                  ) : (
                    <Volume2 className="text-light-text" size={16} />
                  )}
                </Button>
                
                {showVolumeControl && (
                  <div className="w-20">
                    <Slider
                      value={[volume * 100]}
                      onValueChange={handleVolumeChange}
                      max={100}
                      step={1}
                      className="w-full"
                    />
                  </div>
                )}
              </div>

              <Button
                onClick={stop}
                variant="ghost"
                size="sm"
                className="p-1"
              >
                <X className="text-light-text" size={16} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
