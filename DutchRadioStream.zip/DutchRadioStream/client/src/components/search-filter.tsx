import { useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

interface SearchFilterProps {
  onSearch: (query: string) => void;
  onFilter: (genre: string) => void;
  selectedGenre: string;
}

const genres = [
  { id: 'all', label: 'Alle stations' },
  { id: 'news', label: 'Nieuws' },
  { id: 'music', label: 'Muziek' },
  { id: 'talk', label: 'Praatradio' },
];

export function SearchFilter({ onSearch, onFilter, selectedGenre }: SearchFilterProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    onSearch(value);
  };

  return (
    <div className="mb-8">
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="w-full md:w-96">
          <div className="relative">
            <Input
              type="search"
              placeholder="Zoek radiozenders..."
              value={searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-dutch-blue focus:border-transparent outline-none transition-all"
            />
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-light-text" size={16} />
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {genres.map((genre) => (
            <button
              key={genre.id}
              onClick={() => onFilter(genre.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedGenre === genre.id
                  ? 'bg-dutch-blue text-white'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              {genre.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
