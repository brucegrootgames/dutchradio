import { createContext, useContext, useState, useRef, useEffect, ReactNode } from "react";
import { RadioStation } from "@shared/schema";

interface AudioContextType {
  currentStation: RadioStation | null;
  isPlaying: boolean;
  isLoading: boolean;
  volume: number;
  error: string | null;
  playStation: (station: RadioStation) => void;
  togglePlayPause: () => void;
  stop: () => void;
  setVolume: (volume: number) => void;
  clearError: () => void;
}

const AudioContext = createContext<AudioContextType | undefined>(undefined);

export function AudioProvider({ children }: { children: ReactNode }) {
  const [currentStation, setCurrentStation] = useState<RadioStation | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [volume, setVolumeState] = useState(0.7);
  const [error, setError] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Initialize audio element
    audioRef.current = new Audio();
    audioRef.current.volume = volume;
    
    const audio = audioRef.current;

    const handleLoadStart = () => setIsLoading(true);
    const handleCanPlay = () => setIsLoading(false);
    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleError = () => {
      setError('Kan geen verbinding maken met het radiostation. Controleer je internetverbinding en probeer het opnieuw.');
      setIsLoading(false);
      setIsPlaying(false);
    };

    audio.addEventListener('loadstart', handleLoadStart);
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('loadstart', handleLoadStart);
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('error', handleError);
      audio.pause();
    };
  }, []);

  const playStation = (station: RadioStation) => {
    if (!audioRef.current) return;

    setError(null);
    setIsLoading(true);
    setCurrentStation(station);

    const audio = audioRef.current;
    audio.src = station.streamUrl;
    
    audio.play().catch(() => {
      setError('Kan het radiostation niet afspelen. Probeer het opnieuw.');
      setIsLoading(false);
    });
  };

  const togglePlayPause = () => {
    if (!audioRef.current || !currentStation) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(() => {
        setError('Kan het radiostation niet afspelen. Probeer het opnieuw.');
      });
    }
  };

  const stop = () => {
    if (!audioRef.current) return;
    
    audioRef.current.pause();
    audioRef.current.src = '';
    setCurrentStation(null);
    setIsPlaying(false);
    setIsLoading(false);
  };

  const setVolume = (newVolume: number) => {
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
    setVolumeState(newVolume);
  };

  const clearError = () => setError(null);

  return (
    <AudioContext.Provider value={{
      currentStation,
      isPlaying,
      isLoading,
      volume,
      error,
      playStation,
      togglePlayPause,
      stop,
      setVolume,
      clearError
    }}>
      {children}
    </AudioContext.Provider>
  );
}

export function useAudio() {
  const context = useContext(AudioContext);
  if (context === undefined) {
    throw new Error('useAudio must be used within an AudioProvider');
  }
  return context;
}
