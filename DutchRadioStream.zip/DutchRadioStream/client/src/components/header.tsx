import { Radio } from "lucide-react";

export function Header() {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-dutch-blue rounded-full flex items-center justify-center">
              <Radio className="text-white text-lg" size={20} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Dutch Radio</h1>
              <p className="text-sm text-light-text">Nederlandse Radiozenders</p>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-4">
            <div className="text-sm text-light-text">
              <span>2,847</span> luisteraars online
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
