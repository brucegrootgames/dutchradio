import { radioStations, type RadioStation, type InsertRadioStation } from "@shared/schema";

export interface IStorage {
  getAllStations(): Promise<RadioStation[]>;
  getStationById(id: number): Promise<RadioStation | undefined>;
  getStationsByGenre(genre: string): Promise<RadioStation[]>;
  searchStations(query: string): Promise<RadioStation[]>;
}

export class MemStorage implements IStorage {
  private stations: Map<number, RadioStation>;
  private currentId: number;

  constructor() {
    this.stations = new Map();
    this.currentId = 1;
    this.initializeStations();
  }

  private initializeStations() {
    const dutchStations: Omit<RadioStation, 'id'>[] = [
      {
        name: 'NPO Radio 1',
        description: 'Nieuws, Sport & Actualiteiten',
        streamUrl: 'https://icecast.omroep.nl/radio1-bb-mp3',
        genre: 'news',
        logoColor: 'from-red-500 to-red-600',
        logoText: 'NPO 1',
        listeners: 834
      },
      {
        name: 'NPO Radio 2',
        description: 'Gevarieerde Popmuziek',
        streamUrl: 'https://icecast.omroep.nl/radio2-bb-mp3',
        genre: 'music',
        logoColor: 'from-blue-500 to-blue-600',
        logoText: 'NPO 2',
        listeners: 1247
      },
      {
        name: 'Radio 538',
        description: 'Dance & Hits',
        streamUrl: 'https://21633.live.streamtheworld.com/RADIO538.mp3',
        genre: 'music',
        logoColor: 'from-yellow-400 to-orange-500',
        logoText: '538',
        listeners: 1892
      },
      {
        name: 'Sky Radio',
        description: 'Greatest Hits',
        streamUrl: 'https://21603.live.streamtheworld.com/SKYRADIO.mp3',
        genre: 'music',
        logoColor: 'from-purple-500 to-pink-600',
        logoText: 'SKY',
        listeners: 743
      },
      {
        name: 'Qmusic',
        description: 'Hit Music Only',
        streamUrl: 'https://21603.live.streamtheworld.com/QMUSIC.mp3',
        genre: 'music',
        logoColor: 'from-green-500 to-teal-600',
        logoText: 'Q',
        listeners: 1156
      },
      {
        name: 'NPO 3FM',
        description: 'Alternative & Rock',
        streamUrl: 'https://icecast.omroep.nl/3fm-bb-mp3',
        genre: 'music',
        logoColor: 'from-indigo-500 to-purple-600',
        logoText: '3FM',
        listeners: 657
      },
      {
        name: 'NPO Radio 4',
        description: 'Klassieke Muziek',
        streamUrl: 'https://icecast.omroep.nl/radio4-bb-mp3',
        genre: 'music',
        logoColor: 'from-gray-600 to-gray-700',
        logoText: '4',
        listeners: 324
      },
      {
        name: 'NPO Radio 5',
        description: 'Nederlandstalig & Nostalgie',
        streamUrl: 'https://icecast.omroep.nl/radio5-bb-mp3',
        genre: 'music',
        logoColor: 'from-amber-500 to-orange-600',
        logoText: '5',
        listeners: 892
      }
    ];

    dutchStations.forEach(station => {
      const id = this.currentId++;
      this.stations.set(id, { ...station, id });
    });
  }

  async getAllStations(): Promise<RadioStation[]> {
    return Array.from(this.stations.values()).sort((a, b) => b.listeners - a.listeners);
  }

  async getStationById(id: number): Promise<RadioStation | undefined> {
    return this.stations.get(id);
  }

  async getStationsByGenre(genre: string): Promise<RadioStation[]> {
    return Array.from(this.stations.values())
      .filter(station => station.genre === genre)
      .sort((a, b) => b.listeners - a.listeners);
  }

  async searchStations(query: string): Promise<RadioStation[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.stations.values())
      .filter(station => 
        station.name.toLowerCase().includes(lowerQuery) ||
        station.description.toLowerCase().includes(lowerQuery)
      )
      .sort((a, b) => b.listeners - a.listeners);
  }
}

export const storage = new MemStorage();
