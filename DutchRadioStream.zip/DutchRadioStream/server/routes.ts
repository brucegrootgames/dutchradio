import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all radio stations
  app.get("/api/stations", async (req, res) => {
    try {
      const stations = await storage.getAllStations();
      res.json(stations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stations" });
    }
  });

  // Get stations by genre
  app.get("/api/stations/genre/:genre", async (req, res) => {
    try {
      const { genre } = req.params;
      const stations = await storage.getStationsByGenre(genre);
      res.json(stations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stations by genre" });
    }
  });

  // Search stations
  app.get("/api/stations/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }
      const stations = await storage.searchStations(q);
      res.json(stations);
    } catch (error) {
      res.status(500).json({ message: "Failed to search stations" });
    }
  });

  // Get station by ID
  app.get("/api/stations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid station ID" });
      }
      const station = await storage.getStationById(id);
      if (!station) {
        return res.status(404).json({ message: "Station not found" });
      }
      res.json(station);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch station" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
