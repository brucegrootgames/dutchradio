import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const radioStations = pgTable("radio_stations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  streamUrl: text("stream_url").notNull(),
  genre: text("genre").notNull(),
  logoColor: text("logo_color").notNull(),
  logoText: text("logo_text").notNull(),
  listeners: integer("listeners").notNull().default(0),
});

export const insertRadioStationSchema = createInsertSchema(radioStations).omit({
  id: true,
});

export type InsertRadioStation = z.infer<typeof insertRadioStationSchema>;
export type RadioStation = typeof radioStations.$inferSelect;
