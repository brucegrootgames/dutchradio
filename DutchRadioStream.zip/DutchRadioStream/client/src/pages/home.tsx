import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/header";
import { SearchFilter } from "@/components/search-filter";
import { StationGrid } from "@/components/station-grid";
import { AudioPlayer } from "@/components/audio-player";
import { RadioStation } from "@shared/schema";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');
  const [filteredStations, setFilteredStations] = useState<RadioStation[]>([]);

  const { data: stations = [], isLoading } = useQuery<RadioStation[]>({
    queryKey: ['/api/stations'],
  });

  useEffect(() => {
    let filtered = stations;

    // Apply genre filter
    if (selectedGenre !== 'all') {
      filtered = filtered.filter(station => station.genre === selectedGenre);
    }

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(station =>
        station.name.toLowerCase().includes(query) ||
        station.description.toLowerCase().includes(query)
      );
    }

    setFilteredStations(filtered);
  }, [stations, searchQuery, selectedGenre]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleFilter = (genre: string) => {
    setSelectedGenre(genre);
  };

  return (
    <div className="min-h-screen bg-gray-50 font-inter">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <SearchFilter
          onSearch={handleSearch}
          onFilter={handleFilter}
          selectedGenre={selectedGenre}
        />
        
        <StationGrid
          stations={filteredStations}
          isLoading={isLoading}
        />
      </main>

      <AudioPlayer />
    </div>
  );
}
